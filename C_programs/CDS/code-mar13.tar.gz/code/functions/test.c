#include<stdio.h>

int main()
{
	void *pv;
	printf("size=%d\n",sizeof(*pv));
	return 0;
}
