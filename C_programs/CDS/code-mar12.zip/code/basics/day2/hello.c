#include<stdio.h>
/* a comment */

#define MAX 10

int a=10;
int b;

int main()
{
	int y=MAX;
	printf("hello,max=%d\n",y);
	//scanf("%d",y);

	int *p=NULL;
	*p=20;
//	y=square(10);

	return 0;
}
int sum(int x,int y)
{
	return x+y;
}
