#include<stdio.h>

register int y;

int main()
{
	//register int x;
	int x;
	int *p;
	p=&x;

	return 0;
}
