#ifndef __TEST_H
#define __TEST_H

int sum(int,int);

#endif
