#include<stdio.h>

//int m=5;
//const int m=5;
//int xarr[m]; --error

#define MAX 5+3
int xarr[MAX];

int main()
{
	int n;
	printf("enter n val\n");
	scanf("%d",&n);

	int arr[n];

	//int b[2]={10,20,30};

	int nr=3,nc=4;
	int m[nr][nc];

	return 0;
}
