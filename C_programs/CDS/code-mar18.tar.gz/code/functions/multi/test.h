#ifndef __TEST_H
#define __TEST_H

int sum(int,int);
int square(int);

//const int max=10;

#endif
