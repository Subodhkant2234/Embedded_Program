int sum(int p, int q)
{
	int t;
	t = p + q;
	return t;
}
