int diff(int a, int b)
{
	int s;
	s = a - b;
	return s;
}

