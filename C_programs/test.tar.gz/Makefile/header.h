extern int sum(int , int);
extern int diff(int , int);

